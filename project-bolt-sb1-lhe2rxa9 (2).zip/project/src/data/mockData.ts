// This file now serves as a type definition reference only
// Actual data is fetched from the Python backend

import { Game, Skin } from '../types';

export const games: Game[] = [];
export const skins: Skin[] = [];